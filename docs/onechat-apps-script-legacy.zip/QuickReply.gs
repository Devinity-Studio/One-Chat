/**
 * ============================================================
 * QuickReply.gs
 * ============================================================
 * ระบบ "คีย์ลัดข้อความ" คือการตั้งคำย่อ (shortcut) ไว้แทนข้อความยาวๆ
 * ที่พิมพ์บ่อย เช่น พิมพ์ "/ราคา" แล้วระบบดึงข้อความเต็มเรื่องราคามาให้
 *
 * เราเก็บคีย์ลัดไว้ในแท็บ Sheet ชื่อ "QuickReplies" มี 2 คอลัมน์
 * คือ Shortcut กับ FullText เพื่อให้แอดมินที่ไม่ถนัดโค้ดสามารถเข้าไป
 * แก้ไข/เพิ่มคีย์ลัดเองได้ตรงๆ ใน Google Sheet โดยไม่ต้องแตะโค้ดเลย
 * ============================================================
 */

const SHEET_QUICK_REPLIES = 'QuickReplies';
const QUICK_REPLIES_HEADERS = ['Shortcut', 'FullText'];

/**
 * ดึงคีย์ลัดทั้งหมดออกมาเป็น array ของ object เพื่อเอาไปแสดงในหน้า Sidebar
 * (ไฟล์ Sidebar.html จะเรียกฟังก์ชันนี้ผ่าน google.script.run)
 */
function getAllQuickReplies() {
  const sheet = getOrCreateSheet(SHEET_QUICK_REPLIES, QUICK_REPLIES_HEADERS);
  const data = sheet.getDataRange().getValues();

  // ตัดแถวหัวตาราง (index 0) ออก แล้วแปลงแต่ละแถวเป็น object ที่อ่านง่าย
  return data.slice(1).map(function (row) {
    return { shortcut: row[0], fullText: row[1] };
  });
}

/**
 * ค้นหาข้อความเต็มจากคีย์ลัดที่พิมพ์มา
 * ใช้ตอนแอดมินพิมพ์คีย์ลัดในหน้า Sidebar แล้วอยากได้ข้อความเต็มทันที
 */
function resolveQuickReply(shortcut) {
  const all = getAllQuickReplies();
  const found = all.find(function (item) {
    return item.shortcut.toLowerCase() === shortcut.toLowerCase();
  });
  return found ? found.fullText : null;
}

/**
 * เพิ่มคีย์ลัดใหม่ (เรียกจากหน้า Sidebar)
 */
function addQuickReply(shortcut, fullText) {
  appendRowSafely(SHEET_QUICK_REPLIES, QUICK_REPLIES_HEADERS, [shortcut, fullText]);
}
