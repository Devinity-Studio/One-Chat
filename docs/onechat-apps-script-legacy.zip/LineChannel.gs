/**
 * ============================================================
 * LineChannel.gs
 * ============================================================
 * จัดการทุกอย่างที่เกี่ยวกับ Line Official Account
 *
 * หลักการทำงานของ Line Webhook:
 * 1. เมื่อลูกค้าส่งข้อความมาที่ OA, Line จะยิง HTTP POST มาที่
 *    Web App URL ของเรา พร้อมข้อมูลในรูปแบบ JSON
 * 2. เราต้องอ่าน JSON นั้น ดึงข้อความ + userId ออกมา
 * 3. ถ้าจะตอบกลับ ต้องยิง POST ไปที่ Line Messaging API อีกที
 *    (คนละทิศทางกับตอนรับ)
 * ============================================================
 */

/**
 * ประมวลผล event ที่ได้รับจาก Line webhook
 * @param {Object} payload คือ JSON ทั้งก้อนที่ Line ส่งมาใน request body
 */
function handleLineWebhook(payload) {
  // Line จะส่งมาเป็น array ของ events เพราะบางครั้งส่งหลาย event มาพร้อมกัน
  const events = payload.events || [];

  events.forEach(function (event) {
    // เราสนใจเฉพาะ event ประเภทข้อความตัวอักษร (text message)
    if (event.type === 'message' && event.message.type === 'text') {
      const userId = event.source.userId;
      const messageText = event.message.text;
      const replyToken = event.replyToken; // ใช้ตอบกลับได้ครั้งเดียวเท่านั้น ภายในเวลาจำกัด

      // 1) บันทึกลูกค้า + ข้อความลง Sheet ก่อนเสมอ
      const customerKey = upsertCustomer(userId, 'LINE', '');
      logMessage(customerKey, 'LINE', 'IN', messageText);

      // 2) เช็คว่าแอดมินไม่ว่างหรือไม่ ถ้าไม่ว่างให้ AI ตอบแทน
      if (isAdminBusy()) {
        const aiAnswer = getAIReply(messageText, customerKey);
        replyToLine(replyToken, aiAnswer);
        logMessage(customerKey, 'LINE', 'OUT', aiAnswer);
      }
      // ถ้าแอดมินว่าง เราจะไม่ตอบอัตโนมัติ ปล่อยให้แอดมินเข้ามาตอบเองผ่าน
      // Line Official Account Manager ตามปกติ (ระบบนี้แค่ "เก็บข้อมูล" ไว้)
    }
  });
}

/**
 * ส่งข้อความตอบกลับไปที่ Line โดยใช้ Reply API
 * ใช้ replyToken ได้เพียงครั้งเดียว และมีอายุประมาณ 1 นาทีเท่านั้น
 * (เหมาะกับการตอบทันทีตอนรับ webhook)
 */
function replyToLine(replyToken, text) {
  const url = 'https://api.line.me/v2/bot/message/reply';
  const payload = {
    replyToken: replyToken,
    messages: [{ type: 'text', text: text }]
  };

  UrlFetchApp.fetch(url, {
    method: 'post',
    contentType: 'application/json',
    headers: { Authorization: 'Bearer ' + getConfig(CONFIG_KEYS.LINE_ACCESS_TOKEN) },
    payload: JSON.stringify(payload),
    muteHttpExceptions: true // ป้องกันสคริปต์ crash ถ้า Line ตอบ error กลับมา จะได้ log ดูได้
  });
}

/**
 * ส่งข้อความแบบ Push (ใช้ตอนที่ไม่มี replyToken แล้ว เช่น แอดมินพิมพ์ตอบเอง
 * ผ่านหน้า Sidebar ทีหลัง ไม่ใช่ตอบทันทีตอนรับ webhook)
 * การ push แบบนี้ Line จะคิดโควตาการส่งข้อความแยกต่างหาก ต้องระวังปริมาณ
 */
function pushToLine(userId, text) {
  const url = 'https://api.line.me/v2/bot/message/push';
  const payload = { to: userId, messages: [{ type: 'text', text: text }] };

  UrlFetchApp.fetch(url, {
    method: 'post',
    contentType: 'application/json',
    headers: { Authorization: 'Bearer ' + getConfig(CONFIG_KEYS.LINE_ACCESS_TOKEN) },
    payload: JSON.stringify(payload),
    muteHttpExceptions: true
  });
}
