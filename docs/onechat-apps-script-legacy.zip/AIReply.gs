/**
 * ============================================================
 * AIReply.gs
 * ============================================================
 * ไฟล์นี้ทำหน้าที่เรียก Claude API เพื่อให้ AI ช่วยตอบลูกค้าแทนเรา
 * เมื่อเราตั้งสถานะเป็น "ไม่ว่าง"
 *
 * แนวคิดสำคัญ: เราจะส่ง "system prompt" ไปกำกับพฤติกรรมของ AI ก่อน
 * เพื่อให้มันตอบในบทบาทพนักงานร้าน ไม่ใช่ตอบแบบ AI ทั่วไป
 * ============================================================
 */

/**
 * เรียก Claude API เพื่อขอคำตอบสำหรับข้อความลูกค้า
 * @param {string} customerMessage ข้อความที่ลูกค้าพิมพ์มา
 * @param {string} customerKey ใช้ดึงประวัติแชทเก่ามาให้ AI มี context (ทำเพิ่มได้ภายหลัง)
 * @return {string} คำตอบจาก AI
 */
function getAIReply(customerMessage, customerKey) {
  const apiKey = getConfig(CONFIG_KEYS.CLAUDE_API_KEY);
  const url = 'https://api.anthropic.com/v1/messages';

  // system prompt คือ "คำสั่งกำกับบทบาท" ที่ AI จะยึดถือตลอดการสนทนา
  // ควรปรับแก้ข้อความนี้ให้ตรงกับธุรกิจจริงของคุณ (ชื่อร้าน, สินค้า, น้ำเสียง ฯลฯ)
  const systemPrompt =
    'คุณเป็นพนักงานตอบแชทลูกค้าของร้านค้าออนไลน์ ' +
    'ตอบสุภาพ กระชับ เป็นกันเอง ถ้าลูกค้าถามเรื่องที่ไม่แน่ใจ ' +
    'ให้แจ้งว่าจะให้แอดมินตัวจริงติดต่อกลับโดยเร็วที่สุด ' +
    'ห้ามสร้างข้อมูลราคาหรือโปรโมชั่นขึ้นเองถ้าไม่มีข้อมูลจริง';

  const payload = {
    model: 'claude-sonnet-4-5-20250929',
    max_tokens: 500,
    system: systemPrompt,
    messages: [{ role: 'user', content: customerMessage }]
  };

  const options = {
    method: 'post',
    contentType: 'application/json',
    headers: {
      'x-api-key': apiKey,
      'anthropic-version': '2023-06-01'
    },
    payload: JSON.stringify(payload),
    muteHttpExceptions: true // ให้เราอ่าน error message ได้เอง แทนที่จะโดน exception ทันที
  };

  const response = UrlFetchApp.fetch(url, options);
  const responseCode = response.getResponseCode();
  const responseBody = JSON.parse(response.getContentText());

  if (responseCode !== 200) {
    // ถ้า API error (เช่น key ผิด, quota หมด) ให้ log ไว้ดู และตอบข้อความสำรอง
    // แทนที่จะปล่อยให้ระบบล่มทั้งหมด (graceful fallback)
    Logger.log('Claude API Error: ' + JSON.stringify(responseBody));
    return 'ขออภัยค่ะ ขณะนี้แอดมินไม่สะดวกรับสาย รบกวนรอสักครู่ เดี๋ยวเราจะติดต่อกลับโดยเร็วที่สุดค่ะ';
  }

  // โครงสร้างคำตอบของ Claude API: content เป็น array ของ block
  // เราดึงเฉพาะ block ที่ type เป็น 'text' มาต่อกัน
  const textBlocks = responseBody.content.filter(function (block) {
    return block.type === 'text';
  });
  return textBlocks.map(function (block) { return block.text; }).join('\n');
}
