/**
 * ============================================================
 * Config.gs
 * ============================================================
 * ไฟล์นี้ทำหน้าที่เก็บ "ค่าตั้งต้น" ของระบบทั้งหมด เช่น Token ของ
 * Line, Telegram, Facebook และ API Key ของ AI
 *
 * *** ทำไมต้องแยกไฟล์นี้ออกมา ***
 * เพราะเราไม่ควรเขียน Token/API Key ลงในโค้ดตรงๆ (hardcode)
 * เนื่องจากถ้ามีคนอื่นเห็นโค้ด (เช่น แชร์ให้เพื่อนดู, commit ขึ้น GitHub)
 * จะรั่วไหลข้อมูลลับทันที
 *
 * เราจึงใช้ "PropertiesService" ของ Google Apps Script ซึ่งเป็นเหมือน
 * ตู้เซฟเก็บ key-value ที่แยกออกจากตัวโค้ด ต้องเข้าไปตั้งค่าผ่านเมนู
 * Project Settings > Script Properties เท่านั้น
 * ============================================================
 */

// ฟังก์ชันนี้ไว้อ่านค่าจาก Script Properties แบบสั้นๆ
// การเขียนฟังก์ชันห่อไว้แบบนี้เรียกว่า "Wrapper Function"
// ช่วยให้เวลาเรียกใช้งานที่อื่น เขียนสั้นลง และถ้าจะเปลี่ยนวิธีอ่านค่าในอนาคต
// (เช่น เปลี่ยนไปอ่านจาก Sheet แทน) แก้ที่เดียวจบ
function getConfig(key) {
  const value = PropertiesService.getScriptProperties().getProperty(key);
  if (!value) {
    // การ throw error ทันทีเมื่อค่าที่ต้องใช้หายไป ดีกว่าปล่อยให้โค้ด
    // รันต่อไปแล้วพังแบบหาสาเหตุไม่เจอทีหลัง (fail fast principle)
    throw new Error('ไม่พบค่า Config: ' + key + ' กรุณาตั้งค่าใน Script Properties');
  }
  return value;
}

// รายชื่อ key ทั้งหมดที่ระบบต้องใช้ รวมไว้ที่เดียวกันกันพิมพ์ผิด
const CONFIG_KEYS = {
  LINE_ACCESS_TOKEN: 'LINE_ACCESS_TOKEN',       // Channel Access Token จาก Line Developers Console
  LINE_CHANNEL_SECRET: 'LINE_CHANNEL_SECRET',   // ใช้ตรวจสอบลายเซ็นของ webhook (ความปลอดภัย)
  TELEGRAM_BOT_TOKEN: 'TELEGRAM_BOT_TOKEN',     // Token จาก BotFather
  FB_PAGE_ACCESS_TOKEN: 'FB_PAGE_ACCESS_TOKEN', // Page Access Token จาก Facebook App
  FB_VERIFY_TOKEN: 'FB_VERIFY_TOKEN',           // ตัวเลข/ข้อความที่เราตั้งเองสำหรับ verify webhook
  CLAUDE_API_KEY: 'CLAUDE_API_KEY',             // API Key จาก Anthropic Console
  SPREADSHEET_ID: 'SPREADSHEET_ID'              // ID ของ Google Sheet ที่ใช้เก็บข้อมูล
};

/**
 * ฟังก์ชันสำหรับรันครั้งเดียวตอน setup ระบบ
 * เปิดไฟล์นี้ใน Apps Script Editor แล้วกด Run ที่ฟังก์ชันนี้ครั้งเดียว
 * เพื่อตั้งค่าทั้งหมดในทีเดียว (แก้ค่าในเครื่องหมาย '...' ให้เป็นของจริงก่อนรัน)
 */
function setupConfig() {
  const props = PropertiesService.getScriptProperties();
  props.setProperties({
    LINE_ACCESS_TOKEN: 'ใส่ LINE_ACCESS_TOKEN ของคุณ',
    LINE_CHANNEL_SECRET: 'ใส่ LINE_CHANNEL_SECRET ของคุณ',
    TELEGRAM_BOT_TOKEN: 'ใส่ TELEGRAM_BOT_TOKEN ของคุณ',
    FB_PAGE_ACCESS_TOKEN: 'ใส่ FB_PAGE_ACCESS_TOKEN ของคุณ',
    FB_VERIFY_TOKEN: 'ตั้งรหัสอะไรก็ได้ที่คุณจำได้',
    CLAUDE_API_KEY: 'ใส่ CLAUDE_API_KEY ของคุณ',
    SPREADSHEET_ID: 'ใส่ ID ของ Google Sheet (ดูจาก URL ของ Sheet)'
  });
  Logger.log('ตั้งค่า Config เรียบร้อยแล้ว');
}
