# คู่มือติดตั้งระบบ CRM รวม 3 ช่องทาง (GAS + Sheet)

## โครงสร้างไฟล์และหน้าที่

| ไฟล์ | หน้าที่ |
|---|---|
| `Config.gs` | เก็บ Token/API Key ทั้งหมด |
| `SheetDB.gs` | ฟังก์ชันกลางสำหรับอ่าน/เขียน Google Sheet |
| `CustomerService.gs` | บันทึกลูกค้า, ข้อความ, สถานะว่าง/ไม่ว่าง |
| `LineChannel.gs` | รับ-ส่งข้อความ Line OA |
| `TelegramChannel.gs` | รับ-ส่งข้อความ Telegram |
| `FacebookChannel.gs` | รับ-ส่งข้อความ Facebook Messenger |
| `AIReply.gs` | เรียก Claude API ตอบลูกค้าอัตโนมัติ |
| `QuickReply.gs` | จัดการคีย์ลัดข้อความ |
| `Main.gs` | จุดรับ request ทั้งหมด (`doGet`/`doPost`) + เมนู Sidebar |
| `Sidebar.html` | หน้า UI แผงควบคุมของแอดมิน |

## ขั้นตอนติดตั้ง

### 1. สร้าง Google Sheet และโปรเจกต์ Apps Script
1. สร้าง Google Sheet ใหม่ 1 ไฟล์ คัดลอก **Spreadsheet ID** จาก URL
   (ส่วนที่อยู่ระหว่าง `/d/` กับ `/edit`)
2. เมนู Extensions > Apps Script เพื่อเปิด Editor
3. สร้างไฟล์ `.gs` ทั้งหมดตามรายการด้านบน แล้ววางโค้ดตามไฟล์ที่ให้มา
4. สร้างไฟล์ HTML ชื่อ `Sidebar` (เลือกประเภทไฟล์เป็น HTML ตอนสร้าง) แล้ววางโค้ด `Sidebar.html`

### 2. ตั้งค่า Config
1. เปิดไฟล์ `Config.gs` แก้ค่าใน `setupConfig()` ให้เป็นของจริงทั้งหมด
2. เลือกฟังก์ชัน `setupConfig` ที่ dropdown ด้านบน Editor แล้วกด Run (▶) ครั้งเดียว
3. ระบบจะขอ authorize สิทธิ์ครั้งแรก กด Allow ทั้งหมด

### 3. Deploy เป็น Web App
1. มุมขวาบน กด **Deploy > New deployment**
2. เลือกประเภท **Web app**
3. ตั้งค่า Execute as: **Me**, Who has access: **Anyone**
4. กด Deploy แล้วคัดลอก **Web App URL** ที่ได้ (ลงท้ายด้วย `/exec`)

### 4. ผูก Webhook แต่ละช่องทาง

**Telegram** (ง่ายที่สุด)
1. แก้ `WEB_APP_URL` ในฟังก์ชัน `setupTelegramWebhook()` ให้เป็น URL จากข้อ 3
2. Run ฟังก์ชันนี้ครั้งเดียว ดูผลลัพธ์ใน View > Logs ว่าขึ้น `"ok": true`

**Line OA**
1. เข้า Line Developers Console > Messaging API
2. ใส่ Webhook URL เป็น Web App URL จากข้อ 3
3. เปิด "Use webhook" เป็น Enable
4. ปิด "Auto-reply messages" และ "Greeting messages" ของ Line เอง (กันซ้ำกับระบบ AI ของเรา)

**Facebook Messenger**
1. สร้าง Facebook App ที่ developers.facebook.com เพิ่ม product "Messenger"
2. ในส่วน Webhooks ใส่ Callback URL เป็น Web App URL จากข้อ 3
3. ใส่ Verify Token ให้ตรงกับค่า `FB_VERIFY_TOKEN` ที่ตั้งไว้ใน Config
4. เลือก subscription field: `messages`
5. เชื่อม Page ที่ต้องการ แล้วขอ Page Access Token มาใส่ใน Config
6. **หมายเหตุ**: ช่วงแรกจะใช้ได้เฉพาะ role ที่เป็น Admin/Tester ของแอป จนกว่าจะผ่าน App Review

### 5. ทดสอบระบบ
1. เปิด Google Sheet ที่สร้างไว้ จะเห็นเมนู "CRM Panel" ขึ้นด้านบน (ถ้าไม่ขึ้นให้ reload หน้า)
2. กด "เปิดแผงควบคุม" แล้วตั้งสถานะเป็น "ไม่ว่าง"
3. ทักแชทเข้ามาทาง Line/Telegram/Facebook ทดสอบว่า AI ตอบกลับหรือไม่
4. เช็คแท็บ `Customers` และ `Messages` ใน Sheet ว่ามีข้อมูลบันทึกเข้ามา

## แนวทางต่อยอด
- เพิ่มแท็บ `PurchaseEvents` แล้วเรียก `logPurchaseEvent()` เมื่อลูกค้าสั่งซื้อจริง เพื่อใช้วิเคราะห์พฤติกรรม
- เชื่อม Looker Studio เข้ากับ Sheet เพื่อทำ Dashboard วิเคราะห์ยอดขาย/ช่องทางยอดนิยม
- เพิ่ม Trigger แบบ time-based (Triggers > Add Trigger) ให้ AI ส่งข้อความติดตามลูกค้าอัตโนมัติหลังไม่ตอบกลับ X วัน
- เมื่อ traffic เยอะขึ้น ให้พิจารณาย้ายจาก Sheet ไปใช้ฐานข้อมูลจริง (Firebase/PostgreSQL) โดยแก้เฉพาะไฟล์ `SheetDB.gs`
