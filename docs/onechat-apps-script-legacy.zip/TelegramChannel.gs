/**
 * ============================================================
 * TelegramChannel.gs
 * ============================================================
 * Telegram เป็นช่องทางที่ทำ webhook ง่ายที่สุดในสามช่องทาง
 * ไม่ต้องผ่านการ review หรือ verify อะไรซับซ้อน
 *
 * โครงสร้าง JSON ที่ Telegram ส่งมาจะมี field "message" ที่มี
 * chat.id (ใช้ระบุตัวลูกค้า) และ text (ข้อความ)
 * ============================================================
 */

function handleTelegramWebhook(payload) {
  // Telegram ส่งมาเป็น object เดียว (ไม่ใช่ array แบบ Line)
  const message = payload.message;
  if (!message || !message.text) return; // ข้าม ถ้าไม่ใช่ข้อความตัวอักษร (เช่น sticker, รูปภาพ)

  const chatId = message.chat.id;
  const messageText = message.text;
  const displayName = (message.from.first_name || '') + ' ' + (message.from.last_name || '');

  // 1) บันทึกข้อมูลลูกค้า + ข้อความ
  const customerKey = upsertCustomer(chatId, 'TELEGRAM', displayName.trim());
  logMessage(customerKey, 'TELEGRAM', 'IN', messageText);

  // 2) ถ้าแอดมินไม่ว่าง ให้ AI ตอบแทน
  if (isAdminBusy()) {
    const aiAnswer = getAIReply(messageText, customerKey);
    sendTelegramMessage(chatId, aiAnswer);
    logMessage(customerKey, 'TELEGRAM', 'OUT', aiAnswer);
  }
}

/**
 * ส่งข้อความไปที่ Telegram
 * ข้อดีของ Telegram คือไม่มีข้อจำกัดเรื่อง "reply token" เหมือน Line
 * จะส่งข้อความไปหาผู้ใช้เมื่อไหร่ก็ได้ ตราบใดที่ผู้ใช้เคยเริ่มคุยกับบอทมาก่อน
 */
function sendTelegramMessage(chatId, text) {
  const botToken = getConfig(CONFIG_KEYS.TELEGRAM_BOT_TOKEN);
  const url = 'https://api.telegram.org/bot' + botToken + '/sendMessage';

  UrlFetchApp.fetch(url, {
    method: 'post',
    contentType: 'application/json',
    payload: JSON.stringify({ chat_id: chatId, text: text }),
    muteHttpExceptions: true
  });
}

/**
 * ฟังก์ชันช่วย setup: ใช้ผูก Webhook URL ของ GAS เข้ากับ Telegram Bot
 * รันฟังก์ชันนี้ "ครั้งเดียว" หลังจาก Deploy Web App เสร็จแล้ว
 * โดยแก้ WEB_APP_URL ให้เป็น URL ที่ได้จากการ Deploy จริง
 */
function setupTelegramWebhook() {
  const botToken = getConfig(CONFIG_KEYS.TELEGRAM_BOT_TOKEN);
  const webAppUrl = 'ใส่ URL ของ Web App ที่ Deploy แล้ว เช่น https://script.google.com/macros/s/xxxx/exec';
  const url = 'https://api.telegram.org/bot' + botToken + '/setWebhook?url=' + encodeURIComponent(webAppUrl);

  const response = UrlFetchApp.fetch(url, { muteHttpExceptions: true });
  Logger.log(response.getContentText()); // ดูผลลัพธ์ว่าผูกสำเร็จหรือไม่ใน View > Logs
}
