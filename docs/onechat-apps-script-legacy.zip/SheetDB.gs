/**
 * ============================================================
 * SheetDB.gs
 * ============================================================
 * ไฟล์นี้ทำหน้าที่เป็น "ตัวกลาง" ระหว่างโค้ดกับ Google Sheet
 * แนวคิดคือการทำให้ Sheet ทำงานคล้ายฐานข้อมูลแบบง่ายๆ
 * (append row, find row, update row) โดยไฟล์อื่นๆ ไม่ต้องรู้เลยว่า
 * ข้างในเป็น Google Sheet — แค่เรียกฟังก์ชันจากที่นี่พอ
 *
 * *** ทำไมต้องทำแบบนี้ ***
 * ถ้าวันหนึ่งเราอยากย้ายจาก Sheet ไปใช้ฐานข้อมูลจริง (เช่น Firebase)
 * เราจะแก้แค่ไฟล์นี้ไฟล์เดียว ไฟล์อื่นที่เรียกใช้ไม่ต้องแตะเลย
 * หลักการนี้เรียกว่า "Abstraction" (ห่อรายละเอียดไว้ข้างใน)
 * ============================================================
 */

// เปิด Spreadsheet ตาม ID ที่ตั้งไว้ใน Config
// ใช้ Session cache แบบง่ายๆ ด้วยตัวแปร global กัน ไม่ต้องเปิดไฟล์ซ้ำหลายรอบ
let _ss = null;
function getSpreadsheet() {
  if (!_ss) {
    _ss = SpreadsheetApp.openById(getConfig(CONFIG_KEYS.SPREADSHEET_ID));
  }
  return _ss;
}

/**
 * ดึง Sheet (แท็บ) ตามชื่อ ถ้ายังไม่มีให้สร้างใหม่พร้อมใส่หัวตาราง
 * @param {string} sheetName ชื่อแท็บ เช่น "Customers", "Messages"
 * @param {Array<string>} headers หัวตารางที่ต้องการ (ใช้ตอนสร้างแท็บใหม่เท่านั้น)
 */
function getOrCreateSheet(sheetName, headers) {
  const ss = getSpreadsheet();
  let sheet = ss.getSheetByName(sheetName);
  if (!sheet) {
    sheet = ss.insertSheet(sheetName);
    sheet.appendRow(headers);
    sheet.setFrozenRows(1); // แช่แถวหัวตารางไว้ เลื่อนดูข้อมูลสะดวก
  }
  return sheet;
}

/**
 * เพิ่มแถวใหม่ต่อท้าย Sheet พร้อมใช้ LockService ป้องกันข้อมูลชนกัน
 *
 * *** ทำไมต้องมี LockService ***
 * ลองนึกภาพว่ามีลูกค้า 2 คนทักเข้ามาพร้อมกันในเสี้ยววินาทีเดียวกัน
 * ถ้าไม่ล็อก ทั้งสอง request อาจจะอ่านตำแหน่งแถวว่างแถวเดียวกัน
 * แล้วเขียนทับกันเอง ข้อมูลหาย — LockService จะให้ request แรกทำงาน
 * เสร็จก่อน แล้วค่อยปล่อยให้ request ที่สองทำงานต่อ (เข้าคิวทีละคน)
 */
function appendRowSafely(sheetName, headers, rowData) {
  const lock = LockService.getScriptLock();
  try {
    // รอคิวได้สูงสุด 30 วินาที ถ้าเกินจะโยน error ออกมา
    lock.waitLock(30000);
    const sheet = getOrCreateSheet(sheetName, headers);
    sheet.appendRow(rowData);
  } finally {
    // ต้องปล่อยล็อกเสมอไม่ว่าจะสำเร็จหรือ error เพื่อไม่ให้ request อื่นค้าง
    lock.releaseLock();
  }
}

/**
 * ค้นหาแถวจากคอลัมน์ที่กำหนด คืนค่าเป็น object {rowIndex, rowValues}
 * rowIndex เป็นเลขแถวจริงใน Sheet (เอาไว้ใช้ update ต่อ) เริ่มนับที่ 1
 * @param {string} sheetName ชื่อแท็บ
 * @param {string} columnName ชื่อหัวคอลัมน์ที่จะค้นหา เช่น "CustomerID"
 * @param {string} searchValue ค่าที่ต้องการค้นหา
 */
function findRowByColumn(sheetName, columnName, searchValue) {
  const sheet = getSpreadsheet().getSheetByName(sheetName);
  if (!sheet) return null;

  const data = sheet.getDataRange().getValues();
  const headerRow = data[0];
  const colIndex = headerRow.indexOf(columnName);
  if (colIndex === -1) return null;

  // เริ่ม loop จาก index 1 เพราะ index 0 คือหัวตาราง
  for (let i = 1; i < data.length; i++) {
    if (String(data[i][colIndex]) === String(searchValue)) {
      return { rowIndex: i + 1, rowValues: data[i], headers: headerRow };
    }
  }
  return null;
}

/**
 * อัปเดตค่าในแถวที่หาเจอแล้ว โดยระบุเป็น object {ชื่อคอลัมน์: ค่าใหม่}
 * เช่น updateRow('Customers', 5, {Status: 'ปิดการขาย'})
 */
function updateRow(sheetName, rowIndex, columnValueMap) {
  const sheet = getSpreadsheet().getSheetByName(sheetName);
  const headerRow = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0];

  Object.keys(columnValueMap).forEach(function (colName) {
    const colIndex = headerRow.indexOf(colName);
    if (colIndex !== -1) {
      sheet.getRange(rowIndex, colIndex + 1).setValue(columnValueMap[colName]);
    }
  });
}
