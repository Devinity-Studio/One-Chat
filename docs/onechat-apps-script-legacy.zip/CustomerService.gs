/**
 * ============================================================
 * CustomerService.gs
 * ============================================================
 * ไฟล์นี้เป็น "หัวใจ" ของระบบ CRM คือจัดการทุกอย่างที่เกี่ยวกับลูกค้า
 * - บันทึกลูกค้าใหม่ / อัปเดตลูกค้าเดิม
 * - บันทึกประวัติข้อความแชท (ไว้วิเคราะห์พฤติกรรม)
 * - เช็คและตั้งสถานะ "ว่าง/ไม่ว่าง" ของแอดมิน
 * ============================================================
 */

// ชื่อแท็บ Sheet ต่างๆ กำหนดเป็นค่าคงที่ไว้ที่เดียว กันพิมพ์ผิด
const SHEET_CUSTOMERS = 'Customers';
const SHEET_MESSAGES = 'Messages';
const SHEET_EVENTS = 'PurchaseEvents'; // ไว้เก็บ event เช่น ดูสินค้า/สั่งซื้อ เพื่อวิเคราะห์

const CUSTOMERS_HEADERS = ['CustomerID', 'Channel', 'DisplayName', 'FirstContactAt', 'LastContactAt', 'Tags'];
const MESSAGES_HEADERS = ['Timestamp', 'CustomerID', 'Channel', 'Direction', 'MessageText'];
const EVENTS_HEADERS = ['Timestamp', 'CustomerID', 'EventType', 'ProductName', 'Amount'];

/**
 * บันทึกหรืออัปเดตข้อมูลลูกค้า
 * @param {string} customerId รหัสลูกค้า (แต่ละช่องทางจะมี ID เฉพาะของตัวเอง เช่น Line userId)
 * @param {string} channel   'LINE' | 'TELEGRAM' | 'FACEBOOK'
 * @param {string} displayName ชื่อที่แสดงของลูกค้า (ถ้ามี)
 */
function upsertCustomer(customerId, channel, displayName) {
  // เราต้องใช้ customerId ที่ผูกกับ channel เสมอ เพราะ Line userId กับ
  // Telegram chatId อาจจะซ้ำกันโดยบังเอิญได้ (คนละระบบ คนละความหมาย)
  const uniqueKey = channel + '_' + customerId;
  const existing = findRowByColumn(SHEET_CUSTOMERS, 'CustomerID', uniqueKey);
  const now = new Date();

  if (existing) {
    // ลูกค้าเก่า แค่อัปเดตเวลาติดต่อล่าสุด
    updateRow(SHEET_CUSTOMERS, existing.rowIndex, { LastContactAt: now });
  } else {
    // ลูกค้าใหม่ เพิ่มแถวใหม่
    appendRowSafely(SHEET_CUSTOMERS, CUSTOMERS_HEADERS, [
      uniqueKey, channel, displayName || '', now, now, ''
    ]);
  }
  return uniqueKey;
}

/**
 * บันทึกข้อความแชท 1 ข้อความ ทั้งฝั่งลูกค้าส่งเข้ามา และฝั่งเราตอบกลับ
 * @param {string} direction 'IN' (ลูกค้าส่งมา) หรือ 'OUT' (เราตอบไป)
 */
function logMessage(customerUniqueKey, channel, direction, text) {
  appendRowSafely(SHEET_MESSAGES, MESSAGES_HEADERS, [
    new Date(), customerUniqueKey, channel, direction, text
  ]);
}

/**
 * บันทึก Event พฤติกรรม เช่น การดูสินค้า หรือการสั่งซื้อ
 * ฟังก์ชันนี้ยังไม่ได้ต่อเข้ากับ webhook อัตโนมัติ (เพราะแต่ละธุรกิจนิยาม
 * "การซื้อ" ไม่เหมือนกัน) แต่เตรียมไว้ให้เรียกใช้ได้ทันที เช่น เรียกจาก
 * ระบบหลังบ้านของร้านค้าเมื่อมีออเดอร์ใหม่ หรือเรียกจากคีย์เวิร์ดในแชท
 */
function logPurchaseEvent(customerUniqueKey, eventType, productName, amount) {
  appendRowSafely(SHEET_EVENTS, EVENTS_HEADERS, [
    new Date(), customerUniqueKey, eventType, productName || '', amount || 0
  ]);
}

/**
 * ---------- ระบบสถานะ ว่าง/ไม่ว่าง ----------
 * เราเก็บสถานะนี้ไว้ใน Script Properties (ไม่ใช่ Sheet) เพราะเป็นค่า
 * เดี่ยว (single value) ไม่ใช่ตารางข้อมูล อ่านเขียนได้เร็วกว่า Sheet มาก
 */
function isAdminBusy() {
  const status = PropertiesService.getScriptProperties().getProperty('ADMIN_STATUS');
  return status === 'BUSY';
}

function setAdminStatus(status) {
  // status ควรเป็น 'BUSY' หรือ 'AVAILABLE' เท่านั้น
  PropertiesService.getScriptProperties().setProperty('ADMIN_STATUS', status);
}
