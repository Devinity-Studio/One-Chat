/**
 * ============================================================
 * FacebookChannel.gs
 * ============================================================
 * Facebook ยุ่งยากกว่าอีกสองช่องทางเพราะ:
 * 1) ต้องผ่านขั้นตอน "Verify Webhook" ก่อน (ใช้ GET request)
 * 2) ต้องขอสิทธิ์ pages_messaging ผ่าน Facebook App Review
 *    ก่อนถึงจะส่งข้อความหาลูกค้าทั่วไปได้ (ไม่ใช่แค่ทดสอบ)
 * ============================================================
 */

/**
 * Facebook จะยิง GET request มาครั้งแรกตอนเราตั้งค่า Webhook ใน
 * Facebook App Dashboard เพื่อยืนยันว่า URL นี้เป็นของเราจริง
 * เราต้องเช็ค verify_token ให้ตรงกับที่ตั้งไว้ แล้วตอบ challenge กลับไป
 *
 * ฟังก์ชันนี้จะถูกเรียกจาก doGet() หลักของโปรเจกต์ (ดูไฟล์ Main.gs)
 */
function verifyFacebookWebhook(e) {
  const mode = e.parameter['hub.mode'];
  const token = e.parameter['hub.verify_token'];
  const challenge = e.parameter['hub.challenge'];

  if (mode === 'subscribe' && token === getConfig(CONFIG_KEYS.FB_VERIFY_TOKEN)) {
    // ต้องตอบกลับด้วย "challenge" แบบ plain text เท่านั้น ห้ามห่อเป็น JSON
    return ContentService.createTextOutput(challenge);
  }
  return ContentService.createTextOutput('Verification failed').setMimeType(ContentService.MimeType.TEXT);
}

/**
 * ประมวลผลข้อความที่ส่งเข้ามาทาง Facebook Messenger
 * โครงสร้าง payload ของ Facebook จะซ้อนลึกกว่า Line/Telegram เล็กน้อย
 * รูปแบบคือ: entry[] -> messaging[] -> message.text
 */
function handleFacebookWebhook(payload) {
  const entries = payload.entry || [];

  entries.forEach(function (entry) {
    const messagingEvents = entry.messaging || [];
    messagingEvents.forEach(function (event) {
      // เช็คว่ามี field message.text จริงหรือไม่ (กันกรณี event อื่น เช่น "read receipt")
      if (event.message && event.message.text) {
        const senderId = event.sender.id;
        const messageText = event.message.text;

        const customerKey = upsertCustomer(senderId, 'FACEBOOK', '');
        logMessage(customerKey, 'FACEBOOK', 'IN', messageText);

        if (isAdminBusy()) {
          const aiAnswer = getAIReply(messageText, customerKey);
          sendFacebookMessage(senderId, aiAnswer);
          logMessage(customerKey, 'FACEBOOK', 'OUT', aiAnswer);
        }
      }
    });
  });
}

/**
 * ส่งข้อความกลับไปทาง Facebook Messenger ผ่าน Send API
 */
function sendFacebookMessage(recipientId, text) {
  const pageToken = getConfig(CONFIG_KEYS.FB_PAGE_ACCESS_TOKEN);
  const url = 'https://graph.facebook.com/v19.0/me/messages?access_token=' + pageToken;

  const payload = {
    recipient: { id: recipientId },
    message: { text: text }
  };

  UrlFetchApp.fetch(url, {
    method: 'post',
    contentType: 'application/json',
    payload: JSON.stringify(payload),
    muteHttpExceptions: true
  });
}
