/**
 * ============================================================
 * Main.gs
 * ============================================================
 * นี่คือ "ประตูทางเข้า" เดียวของทั้งระบบ Google Apps Script บังคับ
 * ให้ Web App มีฟังก์ชันชื่อ doGet() และ doPost() เท่านั้นเป็นจุดรับ
 * request จากภายนอก เราจึงต้องเขียนตรรกะ "แยกแยะ" ในนี้ว่า request
 * ที่เข้ามาเป็นของช่องทางไหน แล้วค่อยส่งต่อ (delegate) ไปยังไฟล์ที่
 * รับผิดชอบช่องทางนั้นๆ
 *
 * *** วิธีสังเกตว่า request มาจากช่องทางไหน ***
 * - Facebook: ตอน verify จะมี parameter 'hub.mode' ใน GET
 *             ตอนส่งข้อความจริงจะมี field 'object' === 'page' ใน POST body
 * - Telegram: จะมี field 'update_id' อยู่เสมอใน POST body
 * - Line:     จะมี field 'destination' และ 'events' อยู่ใน POST body
 * ============================================================
 */

/**
 * ดักจับ HTTP GET request
 * ใช้สำหรับ Facebook webhook verification เท่านั้น (Line/Telegram ไม่ใช้ GET)
 */
function doGet(e) {
  if (e.parameter && e.parameter['hub.mode']) {
    return verifyFacebookWebhook(e);
  }
  // ถ้าไม่ใช่ verify request ให้ตอบ text ธรรมดาไว้เทสว่า Web App ทำงานอยู่
  return ContentService.createTextOutput('CRM Web App is running.');
}

/**
 * ดักจับ HTTP POST request จากทั้ง 3 ช่องทาง
 * ทุกอย่างเริ่มจากตรงนี้เสมอเมื่อมีข้อความเข้ามาจากลูกค้า
 */
function doPost(e) {
  try {
    // แปลง JSON string ที่ส่งมาใน request body ให้กลายเป็น JavaScript object
    const payload = JSON.parse(e.postData.contents);

    if (payload.update_id !== undefined) {
      // เป็น Telegram
      handleTelegramWebhook(payload);
    } else if (payload.object === 'page') {
      // เป็น Facebook
      handleFacebookWebhook(payload);
    } else if (payload.events !== undefined) {
      // เป็น Line
      handleLineWebhook(payload);
    } else {
      Logger.log('ไม่รู้จัก payload รูปแบบนี้: ' + JSON.stringify(payload));
    }
  } catch (err) {
    // สำคัญมาก: ต้อง catch error ทุกครั้ง เพราะถ้าโค้ดเราพังโดยไม่ catch
    // Line/Telegram/Facebook จะพยายามส่ง webhook เดิมซ้ำๆ มาเรื่อยๆ
    // จนกว่าจะได้ HTTP 200 กลับไป ทำให้ระบบวนลูปยิงซ้ำไม่จบ
    Logger.log('เกิดข้อผิดพลาดใน doPost: ' + err.toString());
  }

  // ทุกช่องทางต้องการ HTTP 200 ตอบกลับเสมอ เพื่อบอกว่า "เราได้รับข้อความแล้ว"
  // ถ้าไม่ตอบ 200 ระบบต้นทางจะคิดว่าส่งไม่สำเร็จแล้วส่งซ้ำมาเรื่อยๆ
  return ContentService.createTextOutput(JSON.stringify({ status: 'ok' }))
    .setMimeType(ContentService.MimeType.JSON);
}

/**
 * เปิดหน้า Sidebar ใน Google Sheet (เมนู Extensions > Apps Script จะมี
 * เมนูกำหนดเองให้กดเปิดได้ ดูฟังก์ชัน onOpen ด้านล่าง)
 */
function showSidebar() {
  const html = HtmlService.createHtmlOutputFromFile('Sidebar')
    .setTitle('CRM Control Panel')
    .setWidth(320);
  SpreadsheetApp.getUi().showSidebar(html);
}

/**
 * ฟังก์ชันพิเศษที่ Google Sheet จะเรียกอัตโนมัติทุกครั้งที่เปิดไฟล์
 * ใช้สร้างเมนูกำหนดเองด้านบน Sheet เพื่อให้แอดมินกดเปิด Sidebar ได้ง่ายๆ
 * โดยไม่ต้องเข้า Apps Script Editor เอง
 */
function onOpen() {
  SpreadsheetApp.getUi()
    .createMenu('CRM Panel')
    .addItem('เปิดแผงควบคุม', 'showSidebar')
    .addToUi();
}
